﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Epsilon_Csharp
{
    class GramWordDec
    {
        public GramWordDec()
        {

        }

        public String[] myGrammar()
        {

            String[] gram = { "epsilon","what is my name", "close app", "hey epsilon", "nevermind", "how to", "what is", "the time", "what time is it", "google", "plus", "minus",
                "times","multiply","divide","divided by","subtract","open","chrome", "search", "how", "do i",
                "spotify", "wake me up", "assuming direct control", "steam", "shutdown pc", "amazon", "weather", "notepad", "internet", "browser",
                "word", "excel", "powerpoint", "current song", "this song", "next song", "last song", "previous song", "pause song", "play song", "stop song", "start song",
                "volume up", "volume down", "file explorer", "start music","stop music","pause music","play music", "last track","previous track","next track", "the date", "hello there", "notepad plus plus", "1","2", "discord", "youtube", "cmd", "command prompt",
                "firefox", "photoshop", "skype", "powershell", "DX diag", "C Cleaner", "how to", "how do i", "how much wood could a wood chuck chuck if a wood chuck could chuck wood",
                "who are you", "next app", "alt tab", "set a timer for", "stop timer"};
            return gram;
        }
    }
}
